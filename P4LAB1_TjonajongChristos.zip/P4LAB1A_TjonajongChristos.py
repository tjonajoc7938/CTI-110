# Christos Tjonajong
# 4/2/25
# P4LAB1A
# Creates a square and triangle

import turtle

wn = turtle.Screen()
shape = turtle.Turtle()

# Square
for side in range(0,4):
    shape.forward(100)
    shape.left(90)
    side += 1

# Triangle
for angle in range(0,3):
    shape.forward(200)
    shape.right(120)



