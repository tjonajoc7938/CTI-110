import turtle

wn = turtle.Screen()
name = turtle.Turtle()

# First Initial
name.left(180)
name.forward(50)
name.right(90)
name.forward(100)
name.right(90)
name.forward(50)

name.penup()
name.forward(50)
name.pendown()

# Second Initial
name.forward(100)
name.left(180)
name.forward(50)
name.left(90)
name.forward(100)


